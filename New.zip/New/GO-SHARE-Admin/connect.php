<?php
$con=mysqli_connect("localhost", "root", "", "go_share_new");
if(mysqli_connect_errno())
{
echo "Connection Fail".mysqli_connect_error();
}
?>