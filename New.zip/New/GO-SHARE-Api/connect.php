<?php
$con=new mysqli('localhost','root','','go_share_new');
// if($con)
// {
//     echo 'successful';
// }
// else
// {
//     echo 'failed';
// }
?>